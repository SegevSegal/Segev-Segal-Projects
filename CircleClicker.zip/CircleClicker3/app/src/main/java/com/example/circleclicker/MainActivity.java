package com.example.circleclicker;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.circleclicker.R;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private ImageView circleImageView;
    private TextView scoreTextView;
    private int score = 0;
    private Random random = new Random();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        circleImageView = findViewById(R.id.circleImageView);
        scoreTextView = findViewById(R.id.scoreTextView);


        circleImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveCircleRandomly();
                updateScore();
            }
        });

        moveCircleRandomly();

    }

    private void moveCircleRandomly()
    {
        int maxX = getResources().getDisplayMetrics().widthPixels - circleImageView.getWidth();
        int maxY = getResources().getDisplayMetrics().heightPixels - circleImageView.getHeight();

        int randomX = random.nextInt(maxX);
        int randomY = random.nextInt(maxY);

        circleImageView.setX(randomX);
        circleImageView.setY(randomY);
    }

    private void updateScore()
    {
        score++;
        scoreTextView.setText("Score: " + score);
    }
}